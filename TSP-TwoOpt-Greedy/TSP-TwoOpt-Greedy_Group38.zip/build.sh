#!/bin/bash

g++ -o tsp tspTwoOptGreedy.cpp -std=c++11
